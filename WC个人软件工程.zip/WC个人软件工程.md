##WC个人软件工程
####1. github项目地址
https://github.com/Sranmi/WC.git
####2. 项目要求
wc.exe 是一个常见的工具，它能统计文本文件的字符数、单词数和行数。这个项目要求写一个命令行程序，模仿已有wc.exe 的功能，并加以扩充，给出某程序设计语言源文件的字符数、单词数和行数。
实现一个统计程序，它能正确统计程序文件中的字符数、单词数、行数，以及还具备其他扩展功能，并能够快速地处理多个文件。
#### 3.预计耗费时间
| PSP2.1 | Personal Software Process Stages |预估耗时（分钟）|实际耗时（分钟）|
| --- | --- |
| Planning | 计划 | 15min |20min
| · Estimate | · 估计这个任务需要多少时间 | 15min |20min
| Development | 开发 | 8hours40min|8hours15min
| · Analysis | · 需求分析 (包括学习新技术) | 2hours|2hours
| · Design Spec | · 生成设计文档 | 1hour |1hour30min
| · Design Review | · 设计复审 (和同事审核设计文档) | 30min|20min
| · Coding Standard | · 代码规范 (为目前的开发制定合适的规范) | 10min |5min
| · Design | · 具体设计 | 1hour |50min
| · Coding | · 具体编码 | 3hours|3hours
| · Code Review | · 代码复审 | 30min|10min
| · Test | · 测试（自我测试，修改代码，提交修改） | 30min|20min
| Reporting | 报告 | 1hour20min|1hour
| · Test Report | · 测试报告 | 40min |30min
| · Size Measurement | · 计算工作量 | 20min |20min
| · Postmortem & Process Improvement Plan | · 事后总结, 并提出过程改进计划 | 20min|10min
| 合计 |   | 10hours15min |9hours35min

#### 4.解题思路
根据题目要求，要实现的内容大致如下：
##### **(1) 基本功能**
* **-c** 统计字符数   
* **-w** 统计单词数   
* **-l** 统计行数  
##### **(2)扩展功能**
+ **-s** 递归处理目录下符合条件的文件
+ **-a** 统计代码行、空行、注释行 
+ 支持各种文件 
##### **(3 )高级功能**
+ **-x** 显示图形界面选择单个文件，并显示所有统计信息  
+ 基本的Windows GUI 程序操作 
+ 通过图形界面展现文件信息 
  
#### 5.设计实现过程
* 建立c# window窗体应用项目 
* 完善窗口界面
* 编写两个类：一个作为执行流程函数，另中一个用于写计算函数
计算字符数 CharCount  
单词数 WordCount  
行数 LineCount  
代码行、空行、注释行 SuperCount
总执行流程 Operator 
选择文件 OpenFile 
执行一次后清除数据 CleanData
用窗口输出字符串功能以及按钮点击功能展示计算结果
确认计算按钮 button2_Click
文件选择按钮 button1_Click
![Alt text](./1536916409892.png)

#### 6.代码说明
下面用扩展功能的supercount举例说明，其他计算函数大致相同，都需要打开数据流。

```
        /// <summary>
        /// 扩展功能：统计代码行、空行、注释行
        /// </summary>
        /// <param name="sr"></param>
        /// <param name="notelinecount"></param>
        /// <param name="nulllinecount"></param>
        /// <param name="codelinecount"></param>
        public void SuperCount (string filename, ref int notelinecount,ref int nulllinecount,ref int codelinecount,ref string showdata)
        {
            //文件流打开文件读取字符
            FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read);
            StreamReader sr = new StreamReader(fs);
            string line;
            while((line =sr.ReadLine ())!=null )
            {
                line = line.Trim(' ');
                line = line.Trim('\t');
                //空行
                if(line ==""||line .Length <=1)//代码中单括号为空行
                {
                    nulllinecount++;
                }
                //注释行
                else if(line.Substring (0,2)=="//"||line .Substring (1,2)=="//")
                {
                    notelinecount++;
                }
                //代码行
                else
                {
                    codelinecount++;
                }
            }
            //读取完需关闭数据流
            sr.Close();
            //在字符串showdata增加计算结果
            showdata += "代码行：" + codelinecount.ToString() + "\n" + "空行：" + nulllinecount.ToString() + "\n" + "注释行：" + notelinecount.ToString() + "\n";
        }

```
打开文件选择窗口，并且设置为单选。
```
private void OpenFile()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = "D:\\";
            ofd.Filter = "所有文件|*.*|文本文件|*.txt";
            ofd.RestoreDirectory = true;
            ofd.Multiselect = false;//一次只能选择单个文件
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                filename = ofd.FileName;
            }
        }
        
```

每次计算完后要清除数据，否则计算结果会累加上一次的数据。
```
        /// <summary>
        /// 输出一次数据后 将数据清零
        /// </summary>
        private void ClearData()
        {
            this.charcount = 0;
            this.wordcount = 0;
            this.linecount = 0;
            showdata = null;
        }

```
界面“确定“按钮，执行函数，以字符串的形式窗口输出数据结果，计算结束清除数据。
```
        private void button2_Click(object sender, EventArgs e)
        {
            Operator();
            if (showdata != null)
                MessageBox.Show(showdata);
            ClearData();
        }
```

参数的判断流程，当参数为-x时要跳出循环，因为-x参数只能单独存在。

```
        /// <summary>
        /// 查询总操作流程
        /// </summary>
        private void Operator()
        {
            //读取用户输入的文件名和参数（其中多个参数以空格分开）
            filename = textBox2.Text;
            parameter = textBox1.Text.Split(' ');
            foreach (var s in parameter)
            {
                if (s != "-c" && s != "-w" && s != "-l" && s != "-s" && s != "-a" && s != "-x")
                {
                    MessageBox.Show("参数输入有误，请重新输入，注意多参数之间必须用空格隔开");
                    break;
                }
                //参数-x输出图形界面选择文件并读取文件名
                if (s == "-x")
                {
                    OpenFile();
                }
                //判断文件是否存在
                if (File.Exists(filename))
                {
                    Function fc = new Function();
                    if (s == "-c" || s == "-x")
                    {
                        fc.CharCount(filename, ref charcount, ref showdata);
                    }
                    if (s == "-w" || s == "-x")
                    {
                        fc.WordCount(filename, ref wordcount, ref showdata);

                    }
                    if (s == "-l" || s == "-x")
                    {
                        fc.LineCount(filename, ref linecount, ref showdata);

                    }
                    if (s == "-a" || s == "-x")
                    {
                        fc.SuperCount(filename, ref notelinecount, ref nulllinecount, ref codelinecount, ref showdata);
                    }
                }
                else
                {
                    MessageBox.Show("文件名不存在，请重新输入");
                    break;
                }
                //参数为"-x"时只能单独使用，跳出循环
                if (s == "-x")
                    break;
            }
        }
```
#### 7.测试运行
WC窗口界面
![Alt text](./1536917930710.png)
测试文本
![Alt text](./1536918120514.png)
输入数据，支持多参数输入
![Alt text](./1536918187978.png)
弹出结果
![Alt text](./1536918230560.png)
当输入系数或者文件目录有误
![Alt text](./1536918424262.png)
![Alt text](./1536918472252.png)

当输入-x或者点击三点按钮时，弹出文件选择窗口，选择文件后，所有数据随即输出。
![Alt text](./1536918570974.png)
![Alt text](./1536918651944.png)
计算扩展-a功能
![Alt text](./1536918748588.png)

#### 8.项目小结
项目过程中遇到的困难：
1.项目是要用命令行的形式还是window窗口应用来实现，最后选择了视觉上较美观的window窗口应用。
2.构思基本功能函数结构时，三个函数分开的话，数据流需要分别执行，但函数可以单独计算，最后选择了单独计算。
3.参数判断时，循环遇到-x时要跳出，以及要如何实现计算函数的运行，最后以计算函数为出发点，符合条件的函数即执行。
4.数据结果该如何呈现，弹出另外一个窗口相比直接输出messagebox较难，最后用字符串在messagebox上执行。
5.运行计算第二次时，发现数据呈叠加状态，即添加一个数据清空函数CleanData。

总结：通过这次个人完成的项目，了解了个人软件工程的设计流程，以及编程过程遇到的问题要在实践中逐步完善。软件工程每个流程的预计时间和设计，到具体的操作和实现，通过查找相关资料，对我这次的软件工程起到了很大的作用。

